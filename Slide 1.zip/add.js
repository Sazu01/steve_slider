const Cammera = document.querySelector(".musk .cam")
const musk_wrapper = document.querySelector(".musk_wrapper")

const nav_l = document.getElementById("l-nav")
const nav_r = document.getElementById("r-nav")

const list_of_slides = document.getElementsByClassName("img_wrapper")

// 

const slide_constent = 351
let slide_processor = -351

//


let track = 1
let max = 2
let min = 0

function mid_always_bigger(mid){
    for (let i of list_of_slides) {
        i.classList.remove("mid_girl")
    }
    list_of_slides[mid].classList.add("mid_girl")
}

//


musk_wrapper.addEventListener("click",(e) => {
    if (e.target === nav_r){
        
        
        if (track < max){
            track += 1
            slide_processor -= slide_constent
            Cammera.style.transform = `translateX(${slide_processor}px)`
        }
        
        console.log(track)
        let mid = track + 1

        mid_always_bigger(mid)
        
        
    }else if (e.target === nav_l){
        
        
        if (track > min){
            track -= 1
            slide_processor += slide_constent
            Cammera.style.transform = `translateX(${slide_processor}px)`
        }
        
        console.log(track)
        let mid = track + 1
        mid_always_bigger(mid)

    }
})


